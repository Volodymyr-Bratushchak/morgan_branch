(function ($) {
  Console.log( 123 ); 
  Drupal.behaviors.menuUiChangeParentItems = {
    attach: function (context, settings) {
      $('#block_hierarchy_menu ul li').off().on('click',(function () {
        $(this).next('ul').toggle('active');
      }));
    }
  };
})(jQuery);

